package com.varya.widgets

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setBackgroundColor(0xFF111111.toInt())
        val pad = (28 * d).toInt()
        box.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "Варя: виджеты"
        title.textSize = 26f
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER

        val hint = TextView(this)
        hint.text = "Чтобы добавить виджет, зажми пустое место на рабочем столе, выбери «Виджеты» и найди «Варя: виджеты». Есть маленький и большой."
        hint.textSize = 17f
        hint.setTextColor(0xFFBBBBBB.toInt())
        hint.gravity = Gravity.CENTER
        hint.setPadding(0, (16 * d).toInt(), 0, 0)

        box.addView(title)
        box.addView(hint)
        setContentView(box)
    }
}
