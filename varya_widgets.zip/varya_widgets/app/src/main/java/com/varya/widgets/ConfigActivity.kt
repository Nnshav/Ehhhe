package com.varya.widgets

import android.app.Activity
import android.app.DatePickerDialog
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.FileOutputStream
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

// Экран настройки: название, дата, фон (своё фото или цвет)
class ConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private lateinit var titleEdit: EditText
    private lateinit var dateBtn: Button
    private lateinit var photoInfo: TextView
    private var date: LocalDate = LocalDate.now()
    private var color: Int = Store.DEFAULT_COLOR
    private val swatches = ArrayList<View>()

    private val palette = listOf(
        0xFF0B0B0B.toInt(), 0xFF14213D.toInt(), 0xFF1B3B2F.toInt(),
        0xFF4A1C2B.toInt(), 0xFF2D1B4E.toInt(), 0xFF5A3A1A.toInt()
    )
    private val dateFmt = DateTimeFormatter.ofPattern("d MMMM yyyy 'г.'", Locale("ru"))
    private val reqPhoto = 101

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val data = Store.load(this, widgetId)
        date = data.date
        color = data.color
        buildUi(data.title)
    }

    private fun label(text: String): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(0xFFAAAAAA.toInt())
        t.textSize = 14f
        t.setPadding(0, dp(18), 0, dp(6))
        return t
    }

    private fun buildUi(title: String) {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(0xFF111111.toInt())
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(40), dp(20), dp(30))
        scroll.addView(col)

        val head = TextView(this)
        head.text = "Настройка виджета"
        head.textSize = 22f
        head.setTextColor(Color.WHITE)
        col.addView(head)

        col.addView(label("Название"))
        titleEdit = EditText(this)
        titleEdit.setText(title)
        titleEdit.setTextColor(Color.WHITE)
        titleEdit.setSingleLine(true)
        col.addView(titleEdit)

        col.addView(label("Дата"))
        dateBtn = Button(this)
        dateBtn.setOnClickListener { pickDate() }
        col.addView(dateBtn)
        refreshDate()

        col.addView(label("Фон"))
        val pick = Button(this)
        pick.text = "Выбрать фото из галереи"
        pick.setOnClickListener { pickPhoto() }
        col.addView(pick)

        val remove = Button(this)
        remove.text = "Убрать фото"
        remove.setOnClickListener {
            Store.photoFile(this, widgetId).delete()
            refreshPhoto()
        }
        col.addView(remove)

        photoInfo = TextView(this)
        photoInfo.setTextColor(0xFFAAAAAA.toInt())
        photoInfo.setPadding(0, dp(6), 0, 0)
        col.addView(photoInfo)
        refreshPhoto()

        col.addView(label("Или цвет (если фото не выбрано)"))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for ((i, c) in palette.withIndex()) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams(dp(44), dp(44))
            lp.setMargins(0, 0, dp(10), 0)
            v.layoutParams = lp
            v.setOnClickListener {
                color = palette[i]
                styleSwatches()
            }
            swatches.add(v)
            row.addView(v)
        }
        col.addView(row)
        styleSwatches()

        val save = Button(this)
        save.text = "Сохранить"
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(28)
        save.layoutParams = lp
        save.setOnClickListener { saveAndFinish() }
        col.addView(save)

        setContentView(scroll)
    }

    private fun styleSwatches() {
        for ((i, v) in swatches.withIndex()) {
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(palette[i])
            g.setStroke(dp(3), if (palette[i] == color) Color.WHITE else 0xFF555555.toInt())
            v.background = g
        }
    }

    private fun refreshDate() {
        dateBtn.text = date.format(dateFmt)
    }

    private fun refreshPhoto() {
        photoInfo.text = if (Store.photoFile(this, widgetId).exists()) "Фото выбрано" else "Фото не выбрано"
    }

    private fun pickDate() {
        DatePickerDialog(
            this,
            { _, y, m, d ->
                date = LocalDate.of(y, m + 1, d)
                refreshDate()
            },
            date.year, date.monthValue - 1, date.dayOfMonth
        ).show()
    }

    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(i, reqPhoto)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPhoto && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) savePhoto(uri)
        }
    }

    // Сжимаем фото и кладём в память приложения, чтобы виджет не терял доступ к нему
    private fun savePhoto(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
                ?: throw IllegalStateException("decode")

            val orient = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val deg = when (orient) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            var out: Bitmap = bmp
            if (deg != 0f) {
                val m = Matrix()
                m.postRotate(deg)
                out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            }
            FileOutputStream(Store.photoFile(this, widgetId)).use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            refreshPhoto()
        } catch (e: Exception) {
            Toast.makeText(this, "Не получилось открыть фото", Toast.LENGTH_LONG).show()
        }
    }

    private fun saveAndFinish() {
        val t = titleEdit.text.toString().trim().ifEmpty { Store.DEFAULT_TITLE }
        Store.save(this, widgetId, WidgetData(t, date, color))
        WidgetUpdater.update(this, AppWidgetManager.getInstance(this), widgetId)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }
}
