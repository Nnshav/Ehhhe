package com.varya.widgets

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.widget.RemoteViews
import java.io.File
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

data class WidgetData(val title: String, val date: LocalDate, val color: Int)

// Настройки каждого виджета (название, дата, цвет) хранятся здесь
object Store {
    const val DEFAULT_TITLE = "Ура"
    const val DEFAULT_DATE = "2027-05-27"
    val DEFAULT_COLOR: Int = 0xFF0B0B0B.toInt()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("widgets", Context.MODE_PRIVATE)

    fun photoFile(ctx: Context, id: Int) = File(ctx.filesDir, "bg_$id.jpg")

    fun load(ctx: Context, id: Int): WidgetData {
        val p = prefs(ctx)
        val date = try {
            LocalDate.parse(p.getString("d_$id", DEFAULT_DATE))
        } catch (e: Exception) {
            LocalDate.parse(DEFAULT_DATE)
        }
        return WidgetData(
            p.getString("t_$id", DEFAULT_TITLE) ?: DEFAULT_TITLE,
            date,
            p.getInt("c_$id", DEFAULT_COLOR)
        )
    }

    fun save(ctx: Context, id: Int, data: WidgetData) {
        prefs(ctx).edit()
            .putString("t_$id", data.title)
            .putString("d_$id", data.date.toString())
            .putInt("c_$id", data.color)
            .apply()
    }

    fun delete(ctx: Context, id: Int) {
        prefs(ctx).edit().remove("t_$id").remove("d_$id").remove("c_$id").apply()
        photoFile(ctx, id).delete()
    }
}

// Рисует фон виджета: своё фото (с затемнением) или цвет, со скруглёнными углами
object Render {
    fun background(ctx: Context, id: Int, large: Boolean, mgr: AppWidgetManager, data: WidgetData): Bitmap {
        val dm = ctx.resources.displayMetrics
        val opts = mgr.getAppWidgetOptions(id)
        val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0).let { if (it > 0) it else if (large) 250 else 110 }
        val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0).let { if (it > 0) it else if (large) 110 else 40 }
        var w = (wDp * dm.density).toInt().coerceAtLeast(2)
        var h = (hDp * dm.density).toInt().coerceAtLeast(2)
        val maxW = 720
        if (w > maxW) {
            h = (h * maxW.toFloat() / w).toInt().coerceAtLeast(2)
            w = maxW
        }
        val radius = if (large) h * 0.2f else h / 2f

        val tmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(tmp)
        val photo = Store.photoFile(ctx, id)
        val src: Bitmap? = if (photo.exists()) BitmapFactory.decodeFile(photo.path) else null
        if (src != null) {
            val scale = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
            val sw = src.width * scale
            val sh = src.height * scale
            val dst = RectF((w - sw) / 2f, (h - sh) / 2f, (w + sw) / 2f, (h + sh) / 2f)
            c.drawBitmap(src, null, dst, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
            c.drawColor(Color.argb(110, 0, 0, 0))
            src.recycle()
        } else {
            c.drawColor(data.color)
        }

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = BitmapShader(tmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        Canvas(out).drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), radius, radius, paint)
        tmp.recycle()
        return out
    }
}

object WidgetUpdater {
    private val dateFmt = DateTimeFormatter.ofPattern("d MMMM yyyy 'г.'", Locale("ru"))

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val classes = listOf(SmallWidget::class.java, LargeWidget::class.java)
        for (cls in classes) {
            for (id in mgr.getAppWidgetIds(ComponentName(ctx, cls))) {
                update(ctx, mgr, id)
            }
        }
    }

    fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
        val info = mgr.getAppWidgetInfo(id) ?: return
        val large = info.provider.className.endsWith("LargeWidget")
        val data = Store.load(ctx, id)
        val days = ChronoUnit.DAYS.between(LocalDate.now(), data.date)

        val (num, label) = when {
            days > 0 -> Pair(days.toString(), "осталось дней")
            days == 0L -> Pair("Сегодня", "")
            else -> Pair((-days).toString(), "дней назад")
        }

        val rv = RemoteViews(ctx.packageName, if (large) R.layout.widget_large else R.layout.widget_small)
        rv.setTextViewText(R.id.title, data.title)
        if (large) {
            rv.setTextViewText(R.id.date, data.date.format(dateFmt))
            rv.setTextViewText(R.id.number, num)
            rv.setTextViewText(R.id.label, label)
        } else {
            rv.setTextViewText(R.id.days, if (label.isEmpty()) num else "$num $label")
        }
        rv.setImageViewBitmap(R.id.bg, Render.background(ctx, id, large, mgr, data))

        // Нажатие на виджет открывает его настройки
        val intent = Intent(ctx, ConfigActivity::class.java)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        val pi = PendingIntent.getActivity(
            ctx, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.root, pi)
        mgr.updateAppWidget(id, rv)
    }
}

open class BaseWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) WidgetUpdater.update(context, appWidgetManager, id)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: android.os.Bundle
    ) {
        WidgetUpdater.update(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        for (id in appWidgetIds) Store.delete(context, id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            Intent.ACTION_DATE_CHANGED, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED ->
                WidgetUpdater.updateAll(context)
        }
    }
}

class SmallWidget : BaseWidget()
class LargeWidget : BaseWidget()
